DOMIVKA — GitHub Pages

1. Створи новий репозиторій на GitHub.
2. Завантаж у нього index.html, style.css і script.js.
3. Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: main / root → Save.
6. Через 1–2 хвилини GitHub дасть адресу виду:
   https://ТВІЙ-USERNAME.github.io/НАЗВА-РЕПОЗИТОРІЮ/

Відкривай цю адресу саме в Safari — тоді JavaScript-кнопки працюватимуть.
